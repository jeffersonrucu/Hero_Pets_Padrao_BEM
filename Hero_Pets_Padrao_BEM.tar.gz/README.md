# Banner Pet-Shop

Banner seguindo a metodologia BEM que é uma metodologia CSS (ou convenção de nomenclatura) usada no mundo todo. Continue lendo para saber o que é CSS BEM, vantagens em se usar, melhores práticas com BEM, exemplos de escrita e muito mais.

## Layout

![ScreenShot](https://raw.githubusercontent.com/jeffersonrucu/Hero_Pets_Padrao_BEM/master/pets.png)


## Referência

 - [BEM: guia definitivo do padrão CSS mais famoso](https://desenvolvimentoparaweb.com/css/bem/)
 - [Layout](https://www.figma.com/file/Hn23BSRugfPKtfN4fBETDI/Pets?node-id=1%3A2)
